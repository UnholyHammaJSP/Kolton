This is the CORE15 branch.
It will contain most recent D2BS 1.5 core changes.
The rest will be the same as in MASTER branch.

The package contains 3 distinct components:
D2BS - core
D2Bot# - manager
kolbot - script library

If you want to contribute to kolbot code, make sure you use JSLint for final polish.
If you want to contribute to d2bs/d2bot#, come to irc.synirc.net/d2bs and ask around.

JSLint options for kolbot code: http://pastebin.com/4t5J9QpL

Also updated with latest assembla
