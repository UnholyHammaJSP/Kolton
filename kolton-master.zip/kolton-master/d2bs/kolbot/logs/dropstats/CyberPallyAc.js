			/**	CyberPallyAc drop info (Thu Oct 22 2015 20:37:01 GMT-0400 (Eastern Standard Time))	*/

{"Magic Find: 287":

	{"Total Runs":0
	"Area: 88":

		{"6 = rare 7 = unquie: 6":

			"Chain Boots":1
			"Swirling Crystal":1

		}

	}

}